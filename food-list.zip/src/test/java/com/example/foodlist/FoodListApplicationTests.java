package com.example.foodlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodListApplicationTests {

    @Test
    void contextLoads() {
    }

}
