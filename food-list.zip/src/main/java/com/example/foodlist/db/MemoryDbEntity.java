package com.example.foodlist.db;

import lombok.Data;

@Data
public abstract class MemoryDbEntity {
    private int index;
}
